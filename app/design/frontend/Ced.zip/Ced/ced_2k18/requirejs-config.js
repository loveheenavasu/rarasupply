var config = {
    map: {
        '*': {
	        "mage/tabs" : "mage/backend/tabs",
            'floatingHeader': 'mage/backend/floating-header',
        }
    }
};