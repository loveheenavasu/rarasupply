var config = {
	"map": {
	    "*": {
	      "Magento_Checkout/template/sidebar.html": "Ced_Advertisement/template/sidebar.html"
	    }
	}
};
