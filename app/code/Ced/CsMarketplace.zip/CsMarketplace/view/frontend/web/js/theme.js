/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_CsMarketplace
 * @author      CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (https://cedcommerce.com/)
 * @license     https://cedcommerce.com/license-agreement.txt
 */
define(
    [
    'jquery',
    'mage/smart-keyboard-handler',
    'mage/mage',
    'mage/ie-class-fixer',
    'domReady!'
    ], function ($, keyboardHandler) {
        'use strict';

        if ($('body').hasClass('checkout-cart-index')) {
            if ($('#co-shipping-method-form .fieldset.rates').length > 0 && $('#co-shipping-method-form .fieldset.rates :checked').length === 0) {
                $('#block-shipping').on(
                    'collapsiblecreate', function () {
                        $('#block-shipping').collapsible('forceActivate');
                    }
                );
            }
        }

        $('.cart-summary').mage(
            'sticky', {
                container: '#maincontent'
            }
        );

        $('.panel.header > .header.links').clone().appendTo('#store\\.links');

        keyboardHandler.apply();
    }
);

