var config = {
    map: {
        '*': {
        	'Magento_Variable/js/config-directive-generator': 'Ced_CsCmsPage/js/ced/cscmspage/config-directive-generator',
            'Magento_Variable/js/custom-directive-generator': 'Ced_CsCmsPage/js/ced/cscmspage/custom-directive-generator'
        }
    }
};
