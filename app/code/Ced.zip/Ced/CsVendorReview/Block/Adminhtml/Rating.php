<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  Ced
 * @package   Ced_CsVendorReview
 * @author    CedCommerce Core Team <connect@cedcommerce.com >
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\CsVendorReview\Block\Adminhtml;

class Rating extends \Magento\Backend\Block\Widget\Grid\Container
{
 
    protected function _construct()
    {
        
        $this->_controller = 'adminhtml_rating';
        $this->_blockGroup = 'Ced_CsVendorReview';
        $this->_headerText = __('Rating');
        $this->_addButtonLabel = __('Add New');
        parent::_construct();
    }
}
